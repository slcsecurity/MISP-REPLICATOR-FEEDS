Setup Instructions

Enter your API key in the authkey file. 

System Requirements:
1. Windows 200x, Windows 7/8 or Linux using WINE(unsupported but works)
2. Must be connected to the Internet

Current Support:
Snort
Suricata
CSV

Adding Support for the following:
STIX
TAXII
XML
RPZ
MD5
IP
SHA256
SHA1
Basic Text